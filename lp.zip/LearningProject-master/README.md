It is a learning App.
Practice is the best of all instructors. At Byju's we know that to for a child to understand concept completely he needs to practice questions related to that topic.

Kids learn better when concept are taught visually. Our pedagogy has video lectures at the core enabling kids to watch and understand the concepts
